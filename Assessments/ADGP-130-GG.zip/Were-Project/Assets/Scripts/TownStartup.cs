﻿using UnityEngine;
using System.Collections;

public class TownStartup
     : MonoBehaviour {

    public GameObject uiPrefab;
	// Use this for initialization
	void Awake ()
    {
      
	}
 
}
